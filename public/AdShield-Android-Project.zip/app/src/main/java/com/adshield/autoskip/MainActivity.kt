package com.adshield.autoskip

import android.annotation.SuppressLint
import android.graphics.Bitmap
import android.os.Bundle
import android.view.View
import android.webkit.*
import android.widget.Button
import android.widget.LinearLayout
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var webView: WebView

    // Universal Multi-OTT 16x Fast-Forward & Sanitizer Scriptlet
    private val universalAdSkipperScriptlet = """
        (function() {
            if (window.__adshield_active) return;
            window.__adshield_active = true;

            // 1. Defuse global ad queues (YouTube, Hotstar, SonyLIV)
            const defuseObject = (obj, keys) => {
                if (!obj || typeof obj !== 'object') return;
                keys.forEach(k => { try { delete obj[k]; } catch(e){} });
            };

            // Poison YouTube ad response
            let ytResp = window.ytInitialPlayerResponse;
            Object.defineProperty(window, 'ytInitialPlayerResponse', {
                get() { defuseObject(ytResp, ['adPlacements', 'playerAds', 'adSlots']); return ytResp; },
                set(v) { ytResp = v; },
                configurable: true
            });

            // 2. High-speed 16x video fast-forward engine for unskippable ads
            setInterval(() => {
                const videos = document.querySelectorAll('video');
                videos.forEach(video => {
                    const isAd = 
                        document.querySelector('.ad-showing') !== null ||
                        document.querySelector('.ytp-ad-player-overlay') !== null ||
                        document.querySelector('[class*="ad-container"]') !== null ||
                        document.querySelector('[id*="ad-container"]') !== null ||
                        document.querySelector('.video-ads') !== null ||
                        document.querySelector('.ad-banner') !== null ||
                        document.querySelector('[aria-label*="Advertisement"]') !== null;

                    if (isAd) {
                        video.muted = true;
                        video.playbackRate = 16.0;
                        if (Number.isFinite(video.duration) && video.duration > 0) {
                            video.currentTime = video.duration - 0.05;
                        }
                    }
                });

                // Click all known skip buttons across Hotstar, SonyLIV, YouTube
                const skipSelectors = [
                    '.ytp-ad-skip-button', '.ytp-skip-ad-button', '.ytp-ad-skip-button-modern',
                    '[class*="skip-ad"]', '[class*="skipAd"]', '[id*="skipAd"]',
                    '[aria-label*="Skip Ad"]', '[aria-label*="Skip"]', 'button:contains("Skip")'
                ];
                skipSelectors.forEach(sel => {
                    try {
                        const btn = document.querySelector(sel);
                        if (btn) btn.click();
                    } catch(e){}
                });
            }, 50);
        })();
    """.trimIndent()

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val rootLayout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }

        // Top OTT Switcher Bar for Family
        val topBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setBackgroundColor(android.graphics.Color.parseColor("#0F172A"))
            setPadding(16, 16, 16, 16)
        }

        fun createOttButton(name: String, url: String): Button {
            return Button(this).apply {
                text = name
                textSize = 12f
                setTextColor(android.graphics.Color.WHITE)
                setBackgroundColor(android.graphics.Color.parseColor("#1E293B"))
                setOnClickListener { webView.loadUrl(url) }
                val params = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                params.setMargins(6, 0, 6, 0)
                layoutParams = params
            }
        }

        topBar.addView(createOttButton("YouTube", "https://m.youtube.com"))
        topBar.addView(createOttButton("Hotstar", "https://www.hotstar.com"))
        topBar.addView(createOttButton("SonyLIV", "https://www.sonyliv.com"))
        topBar.addView(createOttButton("Zee5", "https://www.zee5.com"))

        webView = WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.mediaPlaybackRequiresUserGesture = false
            settings.userAgentString = settings.userAgentString.replace("; wv", "")

            webViewClient = object : WebViewClient() {
                override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                    super.onPageStarted(view, url, favicon)
                    view?.evaluateJavascript(universalAdSkipperScriptlet, null)
                }
                override fun onPageFinished(view: WebView?, url: String?) {
                    super.onPageFinished(view, url)
                    view?.evaluateJavascript(universalAdSkipperScriptlet, null)
                }
            }
        }

        rootLayout.addView(topBar)
        rootLayout.addView(webView, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.MATCH_PARENT))
        setContentView(rootLayout)

        webView.loadUrl("https://m.youtube.com")
    }

    override fun onBackPressed() {
        if (webView.canGoBack()) {
            webView.goBack()
        } else {
            super.onBackPressed()
        }
    }
}
