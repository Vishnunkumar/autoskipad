package com.adshield.autoskip

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityServiceInfo
import android.media.AudioManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

/**
 * AdShield Background Accessibility Service
 * Automatically clicks "Skip Ad" buttons and mutes unskippable commercial audio.
 */
class AdSkipAccessibilityService : AccessibilityService() {

    private lateinit var audioManager: AudioManager
    private var isAdMuted = false

    override fun onServiceConnected() {
        super.onServiceConnected()
        audioManager = getSystemService(AUDIO_SERVICE) as AudioManager
        serviceInfo = AccessibilityServiceInfo().apply {
            eventTypes = AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED or
                         AccessibilityEvent.TYPE_VIEW_CLICKED or
                         AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED
            feedbackType = AccessibilityServiceInfo.FEEDBACK_GENERIC
            flags = AccessibilityServiceInfo.FLAG_REPORT_VIEW_IDS or
                    AccessibilityServiceInfo.FLAG_RETRIEVE_INTERACTIVE_WINDOWS
            packageNames = arrayOf(
                "com.google.android.youtube",
                "in.startv.hotstar",
                "com.jio.media.ondemand"
            )
        }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        val rootNode = rootInActiveWindow ?: return

        // 1. Check for standard YouTube Skip Button ID
        val skipButtons = rootNode.findAccessibilityNodeInfosByViewId(
            "com.google.android.youtube:id/skip_ad_button"
        )
        if (!skipButtons.isNullOrEmpty()) {
            for (node in skipButtons) {
                if (node.isClickable && node.isEnabled) {
                    node.performAction(AccessibilityNodeInfo.ACTION_CLICK)
                    unmuteAudio()
                    return
                }
            }
        }

        // 2. Text-based heuristic search for "Skip Ad" or "Skip"
        val skipTextNodes = rootNode.findAccessibilityNodeInfosByText("Skip")
        if (!skipTextNodes.isNullOrEmpty()) {
            for (node in skipTextNodes) {
                val text = node.text?.toString() ?: ""
                if (text.contains("Skip Ad", ignoreCase = true) || text.equals("Skip", ignoreCase = true)) {
                    findClickableParentAndClick(node)
                    unmuteAudio()
                    return
                }
            }
        }

        // 3. Detect unskippable ads and mute audio stream
        val adBadgeNodes = rootNode.findAccessibilityNodeInfosByText("Ad ·")
        if (!adBadgeNodes.isNullOrEmpty() || !rootNode.findAccessibilityNodeInfosByText("Ad").isNullOrEmpty()) {
            muteAudioDuringUnskippableAd()
        } else if (isAdMuted) {
            unmuteAudio()
        }
    }

    private fun findClickableParentAndClick(node: AccessibilityNodeInfo) {
        var current: AccessibilityNodeInfo? = node
        while (current != null) {
            if (current.isClickable) {
                current.performAction(AccessibilityNodeInfo.ACTION_CLICK)
                return
            }
            current = current.parent
        }
    }

    private fun muteAudioDuringUnskippableAd() {
        if (!isAdMuted) {
            audioManager.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_MUTE, 0)
            isAdMuted = true
        }
    }

    private fun unmuteAudio() {
        if (isAdMuted) {
            audioManager.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_UNMUTE, 0)
            isAdMuted = false
        }
    }

    override fun onInterrupt() {
        unmuteAudio()
    }
}
