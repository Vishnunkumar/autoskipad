package com.adshield.autoskip

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityServiceInfo
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.media.AudioManager
import android.util.DisplayMetrics
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

/**
 * Universal OTT Ad-Skipper & Fast-Forward Engine
 * Targets: YouTube, JioHotstar, SonyLIV, Zee5, JioCinema, MX Player
 */
class AdSkipAccessibilityService : AccessibilityService() {

    private lateinit var audioManager: AudioManager
    private var isAdMuted = false
    private var isFastForwarding = false
    private var displayWidth = 1080
    private var displayHeight = 2400

    // Complete target package list for all major OTT platforms
    companion object {
        val TARGET_PACKAGES = arrayOf(
            "com.google.android.youtube",
            "in.startv.hotstar",                 // JioHotstar (Disney+ Hotstar)
            "com.jio.media.ondemand",            // JioCinema
            "com.msd.sonyliv",                   // SonyLIV (India)
            "com.sony.liv",                      // SonyLIV variant
            "com.graymatrix.did",                // Zee5
            "com.mxtech.videoplayer.ad",         // MX Player
            "com.amazon.avod.thirdpartyclient"   // Prime Video
        )

        // Known Skip Ad Resource IDs across OTT platforms
        val SKIP_BUTTON_IDS = arrayOf(
            // YouTube
            "com.google.android.youtube:id/skip_ad_button",
            "com.google.android.youtube:id/modern_skip_ad_button",
            // Hotstar
            "in.startv.hotstar:id/btn_skip",
            "in.startv.hotstar:id/skip_ad_btn",
            "in.startv.hotstar:id/skip_intro",
            "in.startv.hotstar:id/skip_button",
            // SonyLIV
            "com.msd.sonyliv:id/skip_ad",
            "com.msd.sonyliv:id/btn_skip_ad",
            "com.msd.sonyliv:id/skipAdLayout",
            "com.msd.sonyliv:id/skip_intro_button",
            // JioCinema
            "com.jio.media.ondemand:id/skip_ad",
            "com.jio.media.ondemand:id/skip_btn",
            // Zee5
            "com.graymatrix.did:id/skip_ad_button",
            "com.graymatrix.did:id/btn_skip"
        )

        // Text heuristics for skip actions in multiple languages / formats
        val SKIP_TEXT_KEYWORDS = arrayOf(
            "Skip Ad", "Skip", "Skip in", "Skip Intro", "Skip Recap",
            "Close Ad", "Dismiss Ad"
        )

        // Ad indicator keywords across platforms
        val AD_INDICATORS = arrayOf(
            "Ad ·", "Ad 1 of", "Ad 2 of", "Advertisement", "Sponsored", 
            "Commercial Break", "Ad playing", "Your video will resume",
            "Hotstar Specials", "Powered by"
        )
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        audioManager = getSystemService(AUDIO_SERVICE) as AudioManager

        val metrics: DisplayMetrics = resources.displayMetrics
        displayWidth = metrics.widthPixels
        displayHeight = metrics.heightPixels

        serviceInfo = AccessibilityServiceInfo().apply {
            eventTypes = AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED or
                         AccessibilityEvent.TYPE_VIEW_CLICKED or
                         AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED
            feedbackType = AccessibilityServiceInfo.FEEDBACK_GENERIC
            flags = AccessibilityServiceInfo.FLAG_REPORT_VIEW_IDS or
                    AccessibilityServiceInfo.FLAG_RETRIEVE_INTERACTIVE_WINDOWS
            packageNames = TARGET_PACKAGES
        }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        val rootNode = rootInActiveWindow ?: return
        val currentPackage = event?.packageName?.toString() ?: ""

        // Phase 1: Direct Resource ID Match (Instant Click)
        for (resId in SKIP_BUTTON_IDS) {
            val nodes = rootNode.findAccessibilityNodeInfosByViewId(resId)
            if (!nodes.isNullOrEmpty()) {
                for (node in nodes) {
                    if (clickNodeOrParent(node)) {
                        stopFastForwardAndRestoreAudio()
                        return
                    }
                }
            }
        }

        // Phase 2: Heuristic Text Match ("Skip Ad", "Skip", "Skip Intro")
        for (keyword in SKIP_TEXT_KEYWORDS) {
            val textNodes = rootNode.findAccessibilityNodeInfosByText(keyword)
            if (!textNodes.isNullOrEmpty()) {
                for (node in textNodes) {
                    val text = node.text?.toString() ?: ""
                    if (text.contains(keyword, ignoreCase = true)) {
                        if (clickNodeOrParent(node)) {
                            stopFastForwardAndRestoreAudio()
                            return
                        }
                    }
                }
            }
        }

        // Phase 3: Unskippable Ad Detection (Mute Audio + 2x Fast-Forward Gesture)
        var isCommercialBreak = false
        for (indicator in AD_INDICATORS) {
            if (!rootNode.findAccessibilityNodeInfosByText(indicator).isNullOrEmpty()) {
                isCommercialBreak = true
                break
            }
        }

        if (isCommercialBreak) {
            // Instantly silence loud advertisement audio
            muteAudio()

            // Trigger speed-up gesture (works on YouTube, JioCinema, and player controls)
            trigger2xFastForwardGesture(currentPackage)
        } else {
            stopFastForwardAndRestoreAudio()
        }
    }

    private fun clickNodeOrParent(node: AccessibilityNodeInfo): Boolean {
        var current: AccessibilityNodeInfo? = node
        while (current != null) {
            if (current.isClickable && current.isEnabled) {
                current.performAction(AccessibilityNodeInfo.ACTION_CLICK)
                return true
            }
            current = current.parent
        }
        return false
    }

    private fun trigger2xFastForwardGesture(packageName: String) {
        if (isFastForwarding) return
        isFastForwarding = true

        // Simulate touch-and-hold in the upper-center video viewport
        val videoCenterX = (displayWidth / 2).toFloat()
        val videoCenterY = if (displayWidth > displayHeight) {
            (displayHeight * 0.5f) // Landscape full-screen
        } else {
            (displayHeight * 0.25f) // Portrait orientation
        }

        val touchPath = Path().apply {
            moveTo(videoCenterX, videoCenterY)
        }

        val stroke = GestureDescription.StrokeDescription(touchPath, 0, 1000)
        val gesture = GestureDescription.Builder().addStroke(stroke).build()

        dispatchGesture(gesture, object : GestureResultCallback() {
            override fun onCompleted(gestureDescription: GestureDescription?) {
                super.onCompleted(gestureDescription)
                isFastForwarding = false
            }
            override fun onCancelled(gestureDescription: GestureDescription?) {
                super.onCancelled(gestureDescription)
                isFastForwarding = false
            }
        }, null)
    }

    private fun muteAudio() {
        if (!isAdMuted) {
            audioManager.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_MUTE, 0)
            isAdMuted = true
        }
    }

    private fun stopFastForwardAndRestoreAudio() {
        isFastForwarding = false
        if (isAdMuted) {
            audioManager.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_UNMUTE, 0)
            isAdMuted = false
        }
    }

    override fun onInterrupt() {
        stopFastForwardAndRestoreAudio()
    }
}
