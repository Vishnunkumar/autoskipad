package com.adshield.autoskip

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityServiceInfo
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.media.AudioManager
import android.util.DisplayMetrics
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class AdSkipAccessibilityService : AccessibilityService() {

    private lateinit var audioManager: AudioManager
    private var isAdMuted = false
    private var isFastForwarding = false
    private var displayWidth = 1080
    private var displayHeight = 2400

    companion object {
        val TARGET_PACKAGES = arrayOf(
            "com.google.android.youtube",
            "in.startv.hotstar",
            "com.jio.media.ondemand",
            "com.msd.sonyliv",
            "com.sony.liv",
            "com.graymatrix.did",
            "com.mxtech.videoplayer.ad",
            "com.amazon.avod.thirdpartyclient"
        )

        val SKIP_BUTTON_IDS = arrayOf(
            "com.google.android.youtube:id/skip_ad_button",
            "com.google.android.youtube:id/modern_skip_ad_button",
            "in.startv.hotstar:id/btn_skip",
            "in.startv.hotstar:id/skip_ad_btn",
            "in.startv.hotstar:id/skip_intro",
            "in.startv.hotstar:id/skip_button",
            "com.msd.sonyliv:id/skip_ad",
            "com.msd.sonyliv:id/btn_skip_ad",
            "com.msd.sonyliv:id/skipAdLayout",
            "com.msd.sonyliv:id/skip_intro_button",
            "com.jio.media.ondemand:id/skip_ad",
            "com.jio.media.ondemand:id/skip_btn",
            "com.graymatrix.did:id/skip_ad_button",
            "com.graymatrix.did:id/btn_skip"
        )

        val SKIP_TEXT_KEYWORDS = arrayOf(
            "Skip Ad", "Skip", "Skip in", "Skip Intro", "Skip Recap",
            "Close Ad", "Dismiss Ad"
        )

        val AD_INDICATORS = arrayOf(
            "Ad ·", "Ad 1 of", "Ad 2 of", "Advertisement", "Sponsored", 
            "Commercial Break", "Ad playing", "Your video will resume"
        )
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        audioManager = getSystemService(AUDIO_SERVICE) as AudioManager

        val metrics: DisplayMetrics = resources.displayMetrics
        displayWidth = metrics.widthPixels
        displayHeight = metrics.heightPixels

        serviceInfo = AccessibilityServiceInfo().apply {
            eventTypes = AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED or
                         AccessibilityEvent.TYPE_VIEW_CLICKED or
                         AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED
            feedbackType = AccessibilityServiceInfo.FEEDBACK_GENERIC
            flags = AccessibilityServiceInfo.FLAG_REPORT_VIEW_IDS or
                    AccessibilityServiceInfo.FLAG_RETRIEVE_INTERACTIVE_WINDOWS
            packageNames = TARGET_PACKAGES
        }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        val rootNode = rootInActiveWindow ?: return
        val currentPackage = event?.packageName?.toString() ?: ""

        for (resId in SKIP_BUTTON_IDS) {
            val nodes = rootNode.findAccessibilityNodeInfosByViewId(resId)
            if (!nodes.isNullOrEmpty()) {
                for (node in nodes) {
                    if (clickNodeOrParent(node)) {
                        stopFastForwardAndRestoreAudio()
                        return
                    }
                }
            }
        }

        for (keyword in SKIP_TEXT_KEYWORDS) {
            val textNodes = rootNode.findAccessibilityNodeInfosByText(keyword)
            if (!textNodes.isNullOrEmpty()) {
                for (node in textNodes) {
                    val text = node.text?.toString() ?: ""
                    if (text.contains(keyword, ignoreCase = true)) {
                        if (clickNodeOrParent(node)) {
                            stopFastForwardAndRestoreAudio()
                            return
                        }
                    }
                }
            }
        }

        var isCommercialBreak = false
        for (indicator in AD_INDICATORS) {
            if (!rootNode.findAccessibilityNodeInfosByText(indicator).isNullOrEmpty()) {
                isCommercialBreak = true
                break
            }
        }

        if (isCommercialBreak) {
            muteAudio()
            trigger2xFastForwardGesture()
        } else {
            stopFastForwardAndRestoreAudio()
        }
    }

    private fun clickNodeOrParent(node: AccessibilityNodeInfo): Boolean {
        var current: AccessibilityNodeInfo? = node
        while (current != null) {
            if (current.isClickable && current.isEnabled) {
                current.performAction(AccessibilityNodeInfo.ACTION_CLICK)
                return true
            }
            current = current.parent
        }
        return false
    }

    private fun trigger2xFastForwardGesture() {
        if (isFastForwarding) return
        isFastForwarding = true

        val videoCenterX = (displayWidth / 2).toFloat()
        val videoCenterY = if (displayWidth > displayHeight) {
            (displayHeight * 0.5f)
        } else {
            (displayHeight * 0.25f)
        }

        val touchPath = Path().apply {
            moveTo(videoCenterX, videoCenterY)
        }

        val stroke = GestureDescription.StrokeDescription(touchPath, 0, 1000)
        val gesture = GestureDescription.Builder().addStroke(stroke).build()

        dispatchGesture(gesture, object : GestureResultCallback() {
            override fun onCompleted(gestureDescription: GestureDescription?) {
                super.onCompleted(gestureDescription)
                isFastForwarding = false
            }
            override fun onCancelled(gestureDescription: GestureDescription?) {
                super.onCancelled(gestureDescription)
                isFastForwarding = false
            }
        }, null)
    }

    private fun muteAudio() {
        if (!isAdMuted) {
            audioManager.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_MUTE, 0)
            isAdMuted = true
        }
    }

    private fun stopFastForwardAndRestoreAudio() {
        isFastForwarding = false
        if (isAdMuted) {
            audioManager.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_UNMUTE, 0)
            isAdMuted = false
        }
    }

    override fun onInterrupt() {
        stopFastForwardAndRestoreAudio()
    }
}
