# AdShield Auto-Skip Android App

## How to install on your phone without Android Studio:
1. Upload this repository to GitHub.
2. In GitHub, go to **Actions** -> click **New workflow** -> select **Android CI**.
3. GitHub compiles the APK in the cloud for free!
4. Download the `app-debug.apk` directly to your phone and tap Install.

## To build with Android Studio:
1. Open this folder in Android Studio.
2. Click **Build -> Build APK(s)**.
3. Install the resulting `app-debug.apk` onto your phone.
